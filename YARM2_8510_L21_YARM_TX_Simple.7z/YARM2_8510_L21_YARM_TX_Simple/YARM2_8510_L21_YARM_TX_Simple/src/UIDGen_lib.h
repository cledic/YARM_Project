
/*
*/
uint32_t UID_Gen( uint32_t*long_uid, uint32_t*short_uid);