/*
*/
void EnterIdleMode(void);
void EnterSleepMode(void);
void EnterSleepMode2(void);

void ChkSleepOn( void);
void ChkSleepOff( void);


