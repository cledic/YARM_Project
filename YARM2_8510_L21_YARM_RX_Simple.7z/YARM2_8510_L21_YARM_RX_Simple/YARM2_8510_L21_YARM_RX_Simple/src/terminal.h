
#if USBPRINTF == true
	#define cprintf		myprintf
#else
	#define cprintf		printf
#endif

extern void myprintf( const char* format, ... );

/* VT100 terminal command */
#define ESC	(0x1B)
#define TERM_CLEAR_SCREEN		cprintf("%c[2J", ESC)
#define TERM_CURSOR_HOME		cprintf("%c[H", ESC)
#define TERM_TEXT_RED			cprintf("%c[31m", ESC)
#define TERM_TEXT_GREEN			cprintf("%c[32m", ESC)
#define TERM_TEXT_WHITE			cprintf("%c[37m", ESC)
#define TERM_BKGRD_WHITE		cprintf("%c[47m", ESC)
#define TERM_TEXT_BLUE			cprintf("%c[34m", ESC)
#define TERM_TEXT_BLACK			cprintf("%c[30m", ESC)
#define TERM_TEXT_DEFAULT		cprintf("%c[0m", ESC)
#define TERM_CURSOR_POS(v,h)	cprintf("%c[%d;%dH", ESC,v,h)
//
#define TERM_CURSOR_SAVE		cprintf("%c7", ESC)
#define TERM_CURSOR_RESTORE		cprintf("%c8", ESC)

void Term_Banner( void);
